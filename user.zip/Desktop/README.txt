Patched by giangnam020100: https://github.com/giangnam0201/win7-simu-offline
